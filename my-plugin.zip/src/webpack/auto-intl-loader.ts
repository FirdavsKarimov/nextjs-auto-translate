import { transformCode } from "../transformer/Injector.js";
import { getOptions } from "loader-utils";
import type { LoaderDefinitionFunction } from "webpack";

const loader: LoaderDefinitionFunction = function (source) {
  console.log("🔽 Auto-intl loader called");
  const callback = this.async();
  const options = getOptions(this) || {};

  const transformed = transformCode(source as string, {
    filePath: this.resourcePath,
    sourceMap: options.sourceMap || {}
  });

  callback(null, transformed);
};

export default loader;
