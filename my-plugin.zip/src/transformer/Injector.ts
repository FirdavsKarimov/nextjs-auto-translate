import fs from "fs";
import path from "path";
import { parse } from "@babel/parser";
import traverse, { NodePath } from "@babel/traverse";
import generate from "@babel/generator";
import * as t from "@babel/types";

// Injects <Translated tKey="scope" /> in place of JSXText
export function injectTranslated(scope: string): t.JSXElement {
  return t.jsxElement(
    t.jsxOpeningElement(
      t.jsxIdentifier("Translated"),
      [t.jsxAttribute(t.jsxIdentifier("tKey"), t.stringLiteral(scope))],
      true // self-closing
    ),
    null,
    [],
    true
  );
}

// Ensures import Translated from 'algebras-auto-intl/runtime/client/components/Translated' exists
export function ensureImportTranslated(ast: t.File) {
  let hasImport = false;
  traverse(ast, {
    ImportDeclaration(path) {
      if (
        path.node.source.value ===
          "algebras-auto-intl/runtime/client/components/Translated" &&
        path.node.specifiers.some(
          (s) =>
            t.isImportDefaultSpecifier(s) &&
            t.isIdentifier(s.local) &&
            s.local.name === "Translated"
        )
      ) {
        hasImport = true;
        path.stop();
      }
    }
  });
  if (!hasImport) {
    const importDecl = t.importDeclaration(
      [t.importDefaultSpecifier(t.identifier("Translated"))],
      t.stringLiteral("algebras-auto-intl/runtime/client/components/Translated")
    );
    ast.program.body.unshift(importDecl);
  }
}

// Build-time transformation for individual files (used by webpack loader)
export function transformCode(
  code: string,
  options: { filePath: string; sourceMap: any }
): string {
  let ast;
  try {
    ast = parse(code, {
      sourceType: "module",
      plugins: ["jsx", "typescript"]
    });
  } catch (error) {
    console.warn(`[Injector] Failed to parse ${options.filePath}:`, error);
    return code; // Return original code if parsing fails
  }

  let hasTransformations = false;
  const fileData = options.sourceMap.files[options.filePath];
  if (!fileData) {
    return code; // No translations found for this file
  }

  const fileScopes = fileData.scopes || {};

  traverse(ast, {
    JSXText(path: NodePath<t.JSXText>) {
      const text = path.node.value.trim();
      if (!text) return;

      // Find the closest JSXElement ancestor
      const jsxElement = path.findParent((p) => p.isJSXElement());
      if (!jsxElement) return;

      // Find the scope for this element
      const scopePath = jsxElement
        .getPathLocation()
        .replace(/\[(\d+)\]/g, "$1")
        .replace(/\./g, "/");

      console.log("SCOPEPATH", scopePath);
      if (!fileScopes[scopePath]) return;

      // Replace text with <Translated tKey="scope" />
      path.replaceWith(injectTranslated(`${options.filePath}::${scopePath}`));
      hasTransformations = true;
    }
  });

  if (!hasTransformations) {
    return code; // No transformations needed
  }

  // Ensure Translated component is imported
  ensureImportTranslated(ast);

  // Generate the transformed code
  const result = generate(ast, {
    retainLines: true,
    retainFunctionParens: true
  });

  return result.code;
}

// Transforms all .tsx/.jsx files in the project, injecting t() calls
export async function transformProject(sourceMap: any) {
  const files = Object.keys(sourceMap.files || {});
  for (const filePath of files) {
    const absPath = path.resolve(process.cwd(), filePath);

    if (!fs.existsSync(absPath)) continue;

    const code = fs.readFileSync(absPath, "utf-8");
    let ast;

    try {
      ast = parse(code, {
        sourceType: "module",
        plugins: ["jsx", "typescript"]
      });
    } catch (e) {
      console.warn(`[Injector] Failed to parse ${filePath}:`, e);
      continue;
    }

    let changed = false;
    const fileScopes = sourceMap.files[filePath]?.scopes || {};

    traverse(ast, {
      JSXText(path: NodePath<t.JSXText>) {
        const text = path.node.value.trim();

        if (!text) return;

        // Find the closest JSXElement ancestor
        const jsxElement = path.findParent((p) => p.isJSXElement());
        if (!jsxElement) return;

        // Find the scope for this element
        const scopePath = jsxElement
          .getPathLocation()
          .replace(/\[(\d+)\]/g, "$1")
          .replace(/\./g, "/");

        console.log("SCOPEPATH", scopePath);
        if (!fileScopes[scopePath]) return;

        // Replace text with <Translated tKey="scope" />
        path.replaceWith(injectTranslated(`${filePath}::${scopePath}`));
        changed = true;
      }
    });

    if (changed) {
      ensureImportTranslated(ast);
      const output = generate(ast, { retainLines: true });
      console.log("OUTPUT", output.code);
      // fs.writeFileSync(absPath, output.code, "utf-8");
      // console.log(`[Injector] Transformed ${filePath}`);
    }
  }
}
