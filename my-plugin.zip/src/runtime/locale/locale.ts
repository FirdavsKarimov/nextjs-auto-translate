export const getLocale = () => {};
