// src/index.ts
import fs from "fs";
import type { NextConfig } from "next";
import path from "path";
import { Parser } from "./parser/Parser.js";
import { transformProject } from "./transformer/Injector.js";
import { DictionaryGenerator } from "./translator/DictionaryGenerator.js";
import { fileURLToPath } from "url";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

let hasScheduled = false;

function isProcessAlive(pid: number): boolean {
  try {
    process.kill(pid, 0);
    return true;
  } catch {
    return false;
  }
}

export interface PluginOptions {
  includeNodeModules?: boolean;
  targetLocales?: string[];
  outputDir?: string;
}

export default function myPlugin(options: PluginOptions = {}) {
  const {
    includeNodeModules = false,
    targetLocales = ["en", "es", "fr", "de"],
    outputDir = "./src/intl"
  } = options;

  return function wrapNextConfig(nextConfig: NextConfig): NextConfig {
    const scheduledFlagPath = path.resolve(
      process.cwd(),
      outputDir,
      ".scheduled"
    );

    const parserLockPath = path.resolve(process.cwd(), outputDir, ".lock");
    const pid = process.pid;

    // Check if this process already scheduled
    if (hasScheduled) {
      return nextConfig;
    }

    // Check if ANY process already scheduled parsing
    if (fs.existsSync(scheduledFlagPath)) {
      const flagPid = parseInt(fs.readFileSync(scheduledFlagPath, "utf-8"));
      if (isProcessAlive(flagPid)) {
        return nextConfig;
      } else {
        fs.unlinkSync(scheduledFlagPath);
      }
    }

    hasScheduled = true;

    // Create scheduled flag immediately
    fs.mkdirSync(path.dirname(scheduledFlagPath), { recursive: true });
    fs.writeFileSync(scheduledFlagPath, pid.toString());

    // Clean up any stale parser lock file
    if (fs.existsSync(parserLockPath)) {
      fs.unlinkSync(parserLockPath);
    }

    setImmediate(async () => {
      const asyncTimestamp = new Date().toISOString();

      try {
        const parser = new Parser({ includeNodeModules, outputDir });
        const sourceMap = await parser.parseProject();

        // Generate dictionary
        const dictionaryGenerator = new DictionaryGenerator({
          targetLocales,
          outputDir
        });
        const dictionaryJsonPath = await dictionaryGenerator.generateDictionary(
          sourceMap
        );
      } catch (err) {
        console.error(
          `❌ [${asyncTimestamp}] Parser error (PID: ${pid}):`,
          err
        );
      }

      // Note: NOT removing scheduled flag here - let it persist for the build
    });

    // Return the original nextConfig without webpack modifications
    return {
      ...nextConfig,

      webpack(config, options) {
        config.module.rules.unshift({
          test: /\.[jt]sx?$/,
          exclude: /node_modules/,
          enforce: "pre", // 💡 вставить ДО next-swc-loader
          use: [
            {
              loader: require.resolve("./webpack/auto-intl-loader"),
              options: {
                sourceMap: JSON.parse(
                  fs.readFileSync(
                    path.resolve(outputDir, "source.json"),
                    "utf-8"
                  )
                )
              }
            }
          ]
        });

        // Пробросим оригинальный webpack-хук
        if (typeof nextConfig.webpack === "function") {
          return nextConfig.webpack(config, options);
        }

        return config;
      }
    };
  };
}
